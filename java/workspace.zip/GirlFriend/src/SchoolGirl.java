
public class SchoolGirl {
	String name;
	SchoolGirl(String name)
	{
		this.name=name;
	}
	public String getname()
	{
		return name;
	}
}
