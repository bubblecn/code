
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SchoolGirl jiaojiao=new SchoolGirl("李娇娇");
		Proxy daili=new Proxy(jiaojiao);
		daili.giveflower();
		daili.givedoll();
		daili.givechocolate();
	}

}
