
public interface GiveGift {
	void giveflower();
	void givedoll();
	void givechocolate();
}
