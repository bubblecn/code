
public class Item extends Component {
	public Item(String name)
	{
		super(name);
	}
	@Override
	public void put(Component component) {
		// TODO Auto-generated method stub

	}

	@Override
	public void remove(Component component) {
		// TODO Auto-generated method stub

	}

	@Override
	public void open() {
		// TODO Auto-generated method stub

	}

}
