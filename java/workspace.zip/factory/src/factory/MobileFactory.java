package factory;

public interface MobileFactory {
	public Mobile ProduceMobile();
}
