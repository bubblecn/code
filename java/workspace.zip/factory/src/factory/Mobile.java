package factory;

public interface Mobile {
	public void call();
}
