package factory;

public class NokiaMobile implements Mobile {

	@Override
	public void call() {
		// TODO Auto-generated method stub
		System.out.println("Nokia Mobile");
	}

}
