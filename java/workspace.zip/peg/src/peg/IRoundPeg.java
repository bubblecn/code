package peg;

public interface IRoundPeg {
	public void insertintohole(String msg);
}
