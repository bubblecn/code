package peg;

public interface ISquarePeg {
	public void insert(String msg);
}
