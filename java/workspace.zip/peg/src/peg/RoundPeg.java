package peg;

public class RoundPeg implements IRoundPeg {

	@Override
	public void insertintohole(String msg) {
		// TODO Auto-generated method stub
		System.out.println("insert into hole:"+msg);
	}

}
