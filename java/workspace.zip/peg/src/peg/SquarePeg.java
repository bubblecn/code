package peg;

public class SquarePeg implements ISquarePeg {

	public void insert(String msg) {
		// TODO Auto-generated method stub
		System.out.println("insert:"+msg);
	}

}
