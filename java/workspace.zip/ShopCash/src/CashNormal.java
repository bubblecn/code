
public class CashNormal implements CashSuper {

	@Override
	public double acceptCash(double money) {
		// TODO Auto-generated method stub
		return money; 
	}

}
