
public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Fund jijin = new Fund();
	    //基金购买
	    jijin.BuyFund();
	    //基金赎回
	    jijin.SellFund();

	}

}
