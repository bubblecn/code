
public class NationalDebt1 {
	public void Sell(){
        System.out.println("国债1卖出");
    }
    //买国债
    public void Buy(){
    	System.out.println("国债1买入");
    }
}
