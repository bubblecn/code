
public class Realty1 {
	public void Sell(){
        System.out.println("房地产1卖出");
    }
    //买房地产
    public void Buy(){
    	System.out.println("房地产1买入");
    }
}
