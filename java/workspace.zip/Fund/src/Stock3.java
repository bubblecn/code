
public class Stock3 {
	public void Sell(){
        System.out.println("股票3卖出");
    }
    //买股票
    public void Buy(){
    	System.out.println("股票3买入");
    }
}
