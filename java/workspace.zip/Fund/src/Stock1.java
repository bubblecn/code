
class Stock1 {
	public void Sell(){
        System.out.println("股票1卖出");
    }
    //买股票
    public void Buy(){
    	System.out.println("股票1买入");
    }

}
