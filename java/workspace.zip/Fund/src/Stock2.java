
public class Stock2 {
	public void Sell(){
        System.out.println("股票2卖出");
    }
    //买股票
    public void Buy(){
    	System.out.println("股票2买入");
    }
}
