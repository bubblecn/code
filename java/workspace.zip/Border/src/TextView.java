import java.awt.Component;

public class TextView extends Component {
	public void draw() {
		// Code to draw the TextView object itself.
	}

}
