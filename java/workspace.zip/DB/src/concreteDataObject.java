
public class concreteDataObject extends dataObject {

	@Override
	public void Connect() {
		// TODO Auto-generated method stub
		System.out.println("正在连接数据库");
	}

	@Override
	public void DisConnect() {
		// TODO Auto-generated method stub
		System.out.println("正在断开数据库连接");
	}

	@Override
	public void Process() {
		// TODO Auto-generated method stub
		System.out.println("正在获取数据库数据");
		System.out.println("正在输出数据库数据");
	}

	@Override
	public void Select() {
		// TODO Auto-generated method stub
		System.out.println("正在选择数据库");
	}

}